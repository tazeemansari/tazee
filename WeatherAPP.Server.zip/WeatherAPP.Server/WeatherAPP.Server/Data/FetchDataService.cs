﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using WeatherApp.Models;
using System.IO;
using Newtonsoft.Json;

namespace WeatherAPP.Data
{
    public class FetchDataService
    {
        //public Task<double[]> GetAmountAsync()
        //{
        //    var rng = new Random();

        //    WeatherForecast weatherForecast = null;

        //    using (StreamReader r = new StreamReader("./data/Forecast.json"))
        //    {
        //        string json = r.ReadToEnd();
        //        weatherForecast = JsonConvert.DeserializeObject<WeatherForecast>(json);
        //    }

        //              //return Task.FromResult(Enumerable.Range(1, 6).Select(index => Math.Round(rng.NextDouble() * 1000, 2)).ToArray());
        //    return Task.FromResult(Enumerable.Range(1, 6).Select(index => Math.Round(rng.NextDouble() * 1000, 2)).ToArray());
        //}

        public  WeatherForecast GetWeatherData() 
        {
            WeatherForecast weatherForecast = null;

            using (StreamReader r = new StreamReader("./data/Forecast.json"))
            {
                string json =  r.ReadToEnd();
                weatherForecast  =  JsonConvert.DeserializeObject<WeatherForecast>(json);
            }

            return weatherForecast;

        }

    }
}
